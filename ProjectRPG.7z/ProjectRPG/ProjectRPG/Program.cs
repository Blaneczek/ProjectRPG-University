﻿using ProjectRPG;
using ProjectRPG.Game;

Game game = new();
await game.StartGame();


